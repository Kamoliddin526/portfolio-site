import React, { useState } from "react";
import { Modal } from "antd";
import "./Navbar.scss";
import MediaIcons from './MediaIcons.jpg'

const MediaNavbar = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  return (
    <div className="main__navbar">
        <div className="icon__nav">
            <div className="media__time">9:41</div>
            <div className="media__icons">
                 <img src={MediaIcons} alt="" />
            </div>
        </div>
        <div className="media__navbar">
      <button className="dot__wrapper" onClick={showModal}>
        <div className="dotOne"></div>
        <div className="dotSecond"></div>
        <div className="dotThree"></div>
      </button>
      <Modal
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
        closable={false}
      >
         <ul className="media__nav" style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
                    <li className='mediaNav__item' style={{fontSize: '25px', margin: '10px 0'}}><a style={{color: 'gray'}} href="#"> Home</a></li>
                    <li className='mediaNav__item' style={{fontSize: '25px', margin: '10px 0'}}><a style={{color: 'gray'}} href="#"> Stays</a></li>
                    <li className='mediaNav__item' style={{fontSize: '25px', margin: '10px 0'}}><a style={{color: 'gray'}} href="#"> Flights</a></li>
                    <li className='mediaNav__item' style={{fontSize: '25px', margin: '10px 0'}}><a style={{color: 'gray'}} href="#"> Packages</a></li>
                    <li className='mediaNav__item' style={{fontSize: '25px', margin: '10px 0'}}><a style={{color: 'gray'}} href="#"> Sign Up</a></li>
                </ul>
      </Modal>
      <div className="media__logo">
        <h2>trxvl.</h2>
      </div>
        </div>
    </div>
  );
};

export default MediaNavbar;
